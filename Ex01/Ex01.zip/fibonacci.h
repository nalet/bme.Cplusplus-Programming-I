int fibonacci(int f, int fprev);
double goldenRatio(int f, int fprev);
