#ifndef EX2_1_H
#define EX2_1_H



void ex2_1();


#endif // EX2_1_H
