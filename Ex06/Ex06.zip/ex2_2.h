#ifndef EX2_2_H
#define EX2_2_H



void ex2_2();


#endif // EX2_2_H
