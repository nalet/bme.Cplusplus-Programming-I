#ifndef EX3_2_H
#define EX3_2_H


void ex3_2();
int ex3_2_a();
int ex3_2_b();
int* ex3_2_c(const int length);
int ex3_2_d();

#endif // EX3_2_H
