#ifndef EX3_1_H
#define EX3_1_H



void ex3_1();


#endif // EX3_1_H
