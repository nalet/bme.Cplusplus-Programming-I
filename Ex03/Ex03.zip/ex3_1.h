#ifndef EX3_1_H
#define EX3_1_H



void ex3_1();
void ex3_1_1(unsigned long arraySize);
void ex3_1_2(unsigned long arraySize);
void ex3_1_3(unsigned long arraySize);


#endif // EX3_1_H
