#include <random>

void ex2_picalc();
void throwingADart(std::uniform_real_distribution<double>& dist, std::mt19937& mt);
void throwManyDarts(std::uniform_real_distribution<double>& dist, std::mt19937& mt, int darts);
