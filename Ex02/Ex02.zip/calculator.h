#include <iostream>

using namespace std;

void ex2_functions();
void doubleNumber(int& num);
int addNumbers(int num1 = 0, int num2 = 0, int num3 = 0, int num4 = 0);
void printType(int num);
void printType(float num);
void printType(double num);
void printType(std::string var);
